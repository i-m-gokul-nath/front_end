export interface UserProps{
    first_name?:string;
    last_name?: string;
    role?: string;
    email?: string;  
    password?: string;
    teamId?: number;
}