import Head from 'next/head'
import Image from 'next/image'
import { Inter } from 'next/font/google'
import styles from '@/styles/Home.module.css'
import loggin from '@/components/login'
import Loggin from '@/components/login'
import Avatar from 'antd/es/avatar/avatar'
import AvatarPhoto from '@/components/avatar'
import Link from 'next/link';
import HeaderBeforeLogin from '@/components/HeaderBeforeLogin'
import HeaderAfterLogin from '@/components/HeaderAfterLogin'
// const inter = Inter({ subsets: ['latin'] })

export default function Home() {
  return (
    <>

    <HeaderBeforeLogin/>
     {/* hello */}
     <div className='logging'>
      <Loggin/>
      </div>

      {/* <img src="/home/sprakashtiwari/Pictures/logo.png" alt="LOGO" /> */}
      <div className='logo'>
      <img src="/logo.png" alt="logo"></img>
      </div>
      <div className='avatar'>
      <AvatarPhoto ></AvatarPhoto>
      </div>
    </>
  )
}