import Head from 'next/head'
import Image from 'next/image'
import { Inter } from 'next/font/google'
import styles from '@/styles/Home.module.css'
// import loggin from '@/components/loggin'
// import Loggin from '@/components/loggin'
import Avatar from 'antd/es/avatar/avatar'
import AvatarPhoto from '@/components/avatar'
import Link from 'next/link';
import ResetPassword from '@/components/changePass'
import HeaderBeforeLogin from '@/components/HeaderBeforeLogin'
// const inter = Inter({ subsets: ['latin'] })

export default function Home() {
  return (
    <>
    <HeaderBeforeLogin/>
     {/* hello */}
     <div className='loging'>
        <ResetPassword/>

      </div>
      <div className='logo'>
      <img src="/logo.png" alt="logo"></img>
      </div>
      

    </>
  )
}