import React from 'react';
import { Button, Checkbox, Form, Input } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';

import './loging.module.css';
import Link from 'next/link';

const API_URL = 'http://localhost:3002';

const Login: React.FC = () => {
  const [form] = Form.useForm();

  const handleReset = () => {
    form.resetFields();
  };
  const ud = {
    "email": "abc@gmail.com",
    "old_password": "4567",
    "new_password": "salman123"
  };

  const onFinish = async (values: any) => {
    const { username, password, password1, password2 } = values;

    try {
      // Fetch user data from the API
      const response = await fetch(`${API_URL}/user?username=${username}`);
      const userData = await response.json();
      
      console.log(userData)
      console.log(values)
      console.log(parseInt(values.username))
      
      const user = userData.find((user: any) => {
        console.log(user.userId, parseInt(values.username))
        console.log(user.password,values.password)
        return user.userId === parseInt(values.username) && user.password === values.password;
      });


      // if (user) {
      //   window.location.href = "/loggedinn";
      // } else {
      //   // window.location.href = "/login";
      // }

      if (1) {
        // Get the user's password
        fetch('http://localhost:3002/user/password', {
        method: 'GET',
        })
        .then(response => response.json())
        .then(data => {
          // Update the user's password with the new value
          const updatedUser = {
            ...data,
            password: values.password2
          };

          // Send the updated user data to the server
          fetch('http://localhost:5000/user/password', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(ud)
          })
          .then(response => response.json())
          .then(data => {
            // Password updated successfully
            // Navigate to the logged-in page
            // history.push('/loggedinn');
            console.log("HO GYA BHAI")
          })
          .catch(error => {
            console.error('Error updating password:', error);
            // Display an error message to the user
            // and stay on the same page
          });
        })
        .catch(error => {
          console.error('Error getting user data:', error);
          // Display an error message to the user
          // and stay on the same page
        });
      }
      else {
          console.log("ELSE ME AAYA BHAI")
          // window.location.href = "http://localhost:3000/changepassword";
        }
      




      // Compare username and password with the user data from the API
      // if (userData.username === username && userData.password === password) {
      //   // Update password
      //   if (password1 === password2) {
      //     await fetch(`${API_URL}/user/${userData.id}`, {
      //       method: 'PATCH',
      //       headers: {
      //         'Content-Type': 'application/json',
      //       },
      //       body: JSON.stringify({ password: password1 }),
      //     });

      //     // Redirect to the loggedin page
      //     window.location.href = '/loggedin';
      //   } else {
      //     console.log('Passwords do not match');
      //   }
      // } else {
      //   console.log('Invalid username or password');
      // }
    } catch (error) {
      console.log('Error fetching user data:', error);
    }
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <div className="login-container">
      <div className="login-header">
        <br />
        <br />
        <br />
        <br />
      </div>
      <Form
        name="basic"
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
      >
        <Form.Item
          name="username"
          rules={[{ required: true, message: 'Please input your username!' }]}
        >
          <Input placeholder="User Name" prefix={<UserOutlined />} />
        </Form.Item>

        <Form.Item
          name="password"
          rules={[{ required: true, message: 'Please input your password!' }]}
        >
          <Input.Password placeholder="Password" prefix={<LockOutlined />} />
        </Form.Item>

        <Form.Item
          name="password1"
          rules={[{ required: true, message: 'Please input your new password!' }]}
        >
          <Input.Password placeholder="New Password" prefix={<LockOutlined />} />
        </Form.Item>

        <Form.Item
          name="password2"
          rules={[{ required: true, message: 'Please confirm your new password!' }]}
        >
          <Input.Password placeholder="Confirm Password" prefix={<LockOutlined />} />
        </Form.Item>

        <Form.Item>
          <Button htmlType="button" onClick={handleReset} className="reset-button">
            Reset
          </Button>
          <Button type="primary" htmlType="submit" className="login-button">
            Confirm
          </Button>
        </Form.Item>
      </Form>


      <Link href="/">
        <p typeof="button">Click here to Login</p>
      </Link>
    </div>
  );
};

export default Login;