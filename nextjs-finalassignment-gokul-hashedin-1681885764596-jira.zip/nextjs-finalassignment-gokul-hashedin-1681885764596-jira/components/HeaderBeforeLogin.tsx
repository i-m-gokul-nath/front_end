function HeaderBeforeLogin(){
    return(
    <div className="header1">
        <div className="title">
            HU PROJECT TRACKER
        </div>
        </div>
        
    )
}

export default HeaderBeforeLogin;