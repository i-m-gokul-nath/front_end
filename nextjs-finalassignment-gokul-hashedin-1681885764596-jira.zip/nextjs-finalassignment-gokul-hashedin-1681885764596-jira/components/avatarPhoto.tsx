import { UserOutlined } from '@ant-design/icons';
import { Avatar, Space } from 'antd';
import React from 'react';
const AvatarPhoto = () => (
  <Space size={16} wrap>
    <Avatar 
    size={30}
    icon={<UserOutlined />} />
  </Space>
);

export default AvatarPhoto;