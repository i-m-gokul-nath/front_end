// import React from 'react';
// import { Button, Checkbox, Form, Input } from 'antd';
// import { UserOutlined, LockOutlined } from '@ant-design/icons';
// import './loging.module.css';

// const onFinish = (values: any) => {
//   console.log('Success:', values);
// };

// const onFinishFailed = (errorInfo: any) => {
//   console.log('Failed:', errorInfo);
// };

// const Login: React.FC = () => {
//   const [form] = Form.useForm();

//   const handleReset = () => {
//     form.resetFields();
//   };

//   return (
//     <div className="login-container">
//       <div className="login-header">
//         <br />
//         <br />
//         <br />
//         <br />
//       </div>

//       <Form
//         name="basic"
//         initialValues={{ remember: true }}
//         onFinish={onFinish}
//         onFinishFailed={onFinishFailed}
//         autoComplete="off"
//         form={form}
//       >
//         <Form.Item
//           name="username"
//           rules={[{ required: true, message: 'Please input your username!' }]}
//         >
//           <Input placeholder="Username" prefix={<UserOutlined />} />
//         </Form.Item>

//         <Form.Item
//           name="password"
//           rules={[{ required: true, message: 'Please input your password!' }]}
//         >
//           <Input.Password placeholder="Password" prefix={<LockOutlined />} />
//         </Form.Item>

//         <Form.Item>
//           <Button htmlType="button" onClick={handleReset} className="reset-button">
//             Reset
//           </Button>
//           <Button type="primary" htmlType="submit" className="login-button">
//             Confirm
//           </Button>
//         </Form.Item>
//       </Form>
//     </div>
//   );
// };

// export default Login;


// *****************************************************************

import React from 'react';
import { Button, Checkbox, Form, Input } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import './loging.module.css';
import Link from 'next/link';

const onFinish = async (values: any) => {
  console.log('Success:', values);

  try {
    const response = await fetch('http://localhost:3002/user');
    const data = await response.json();

    // console.log(data[0].email)
    // console.log(values.username)
    if (data.username === values.username) {
      window.location.href = 'http://localhost:3000/';
    } else {
      window.location.href = 'http://localhost:3000/';
    }
  } catch (error) {
    console.log(error);
  }
};

const onFinishFailed = (errorInfo: any) => {
  console.log('Failed:', errorInfo);
};

const Login: React.FC = () => {
  const [form] = Form.useForm();

  const handleReset = () => {
    form.resetFields();
  };

  return (
    <div className="login-container">
      <div className="login-header">
        <br />
        <br />
        <br />
        <br />
      </div>

      <Form
        name="basic"
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
      >
        <Form.Item
          name="username"
          rules={[{ required: true, message: 'Please input your username!' }]}
        >
          <Input placeholder="Username" prefix={<UserOutlined />} />
        </Form.Item>

        <Form.Item
          name="password"
          rules={[{ required: true, message: 'Please input your password!' }]}
        >
          <Input.Password placeholder="Password" prefix={<LockOutlined />} />
        </Form.Item>

        <Form.Item>
          <Button htmlType="button" onClick={handleReset} className="reset-button">
            Reset
          </Button>
          <Button type="primary" htmlType="submit" className="login-button">
            Confirm
          </Button>
        </Form.Item>
      </Form>

      <Link href="/changepassword">
    <p typeof='button'>Click here to change password</p>
      </Link>
      
    </div>
  );
};

export default Login;