import { UserProps } from "@/model/user.model";
import AvatarPhoto from "./avatarPhoto";

function HeaderAfterLogin(user:UserProps){
    const username=user.first_name+" "+user.last_name;
    return(
    <div className="header1">
        <div className="title">
            HU PROJECT TRACKER
        </div>
        <div className="usertag">
            <div className="userName">
            {username}
            </div>
            <div className="userAvatar"> 
            <AvatarPhoto ></AvatarPhoto>
            </div>
        </div>
    </div>
    )
}
export default HeaderAfterLogin;